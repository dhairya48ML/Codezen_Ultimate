# CodeZen CLI

This is the command-line interface for CodeZen Ultimate AI Agent.
